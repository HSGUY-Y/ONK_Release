function Component()
{

}

Component.prototype.createOperations = function()
{
    component.createOperations();
     if (systemInfo.productType === "windows") {
        component.addOperation("CreateShortcut",
            "@TargetDir@/ControlerHost",
            "@StartMenuDir@/ControlerHost.lnk",
            "workingDirectory=@TargetDir@",
            "iconPath=@TargetDir@/ControlerHost.exe",
            "iconId=0",
            "description=Open ControlerHost");
        component.addOperation("CreateShortcut",
            "@TargetDir@/ControlerHost",
            "@DesktopDir@/ControlerHost.lnk",
            "workingDirectory=@TargetDir@",
            "iconPath=@TargetDir@/ControlerHost.exe",
            "iconId=0",
            "description=Open ControlerHost");
    }

}

