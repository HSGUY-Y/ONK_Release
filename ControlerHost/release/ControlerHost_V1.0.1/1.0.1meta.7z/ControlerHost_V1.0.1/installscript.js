function Component()
{
    // default constructor
    var current = component;
    var all = [
        "ControlerHost_V1.0.0",
        "ControlerHost_V1.0.1"
    ];

    component.setCheckable(true);

    component.clicked.connect(function() {
        if (current.checked) {
            for (var i = 0; i < all.length; ++i) {
                var otherName = all[i];
                if (otherName !== current.name) {
                    var other = installer.componentByName(otherName);
                    if (other && other.checked)
                        other.setChecked(false);
                }
            }
        }
    });
}

Component.prototype.createOperations = function()
{
    
    // call default implementation to actually install something
    component.createOperations();
    if(systemInfo.productType == "windows")
    {
        component.addOperation("CreateShortcut", "@TargetDir@/ControlerHost", "@StartMenuDir@/ControlerHost.lnk",
            "workingDirectory=@TargetDir@", "iconPath=%SystemRoot%/system32/SHELL32.dll",
            "iconId=2", "description=Open ControlerHost");
    }
}